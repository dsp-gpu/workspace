# =============================================================================
# version.cmake — Запускается при КАЖДОЙ сборке через add_custom_target
#
# Вызов: cmake -D SRC_DIR=... -D BIN_DIR=... -D GIT_EXECUTABLE=... -P version.cmake
#
# Собирает ВСЮ информацию из Git и генерирует version.h через configure_file.
# Ключевая особенность: configure_file НЕ трогает файл, если содержимое
# не изменилось → пересборка downstream только при реальном изменении.
# =============================================================================

# --- 1. Commit hash (short + full) ---
execute_process(
    COMMAND ${GIT_EXECUTABLE} rev-parse --short=7 HEAD
    WORKING_DIRECTORY "${SRC_DIR}"
    OUTPUT_VARIABLE GIT_HASH_SHORT
    OUTPUT_STRIP_TRAILING_WHITESPACE
    ERROR_QUIET
    RESULT_VARIABLE GIT_RESULT
)

if(NOT GIT_RESULT EQUAL 0)
    # Нет git (zip-архив, отсутствует .git)
    set(GIT_HASH_SHORT  "unknown")
    set(GIT_HASH_FULL   "unknown")
    set(GIT_TAG         "v0.0.0")
    set(GIT_BRANCH      "unknown")
    set(GIT_DIRTY       "")
    set(GIT_DIRTY_FLAG  0)
    set(GIT_COMMITS     "0")
    set(GIT_DATE        "unknown")
    set(GIT_DESCRIBE    "v0.0.0-unknown")
    set(VERSION_MAJOR   0)
    set(VERSION_MINOR   0)
    set(VERSION_PATCH   0)
    message(STATUS "[version] Git not available, using defaults")
else()
    # Full hash
    execute_process(
        COMMAND ${GIT_EXECUTABLE} rev-parse HEAD
        WORKING_DIRECTORY "${SRC_DIR}"
        OUTPUT_VARIABLE GIT_HASH_FULL
        OUTPUT_STRIP_TRAILING_WHITESPACE
    )

    # --- 2. Branch ---
    execute_process(
        COMMAND ${GIT_EXECUTABLE} rev-parse --abbrev-ref HEAD
        WORKING_DIRECTORY "${SRC_DIR}"
        OUTPUT_VARIABLE GIT_BRANCH
        OUTPUT_STRIP_TRAILING_WHITESPACE
    )

    # --- 3. Dirty flag (uncommitted changes) ---
    execute_process(
        COMMAND ${GIT_EXECUTABLE} diff --quiet --exit-code
        WORKING_DIRECTORY "${SRC_DIR}"
        RESULT_VARIABLE GIT_DIRTY_RESULT
    )
    if(GIT_DIRTY_RESULT EQUAL 0)
        set(GIT_DIRTY "")
        set(GIT_DIRTY_FLAG 0)
    else()
        set(GIT_DIRTY "+dirty")
        set(GIT_DIRTY_FLAG 1)
    endif()

    # --- 4. Tag (nearest annotated tag) ---
    execute_process(
        COMMAND ${GIT_EXECUTABLE} describe --tags --abbrev=0
        WORKING_DIRECTORY "${SRC_DIR}"
        OUTPUT_VARIABLE GIT_TAG
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
        RESULT_VARIABLE TAG_RESULT
    )
    if(NOT TAG_RESULT EQUAL 0)
        set(GIT_TAG "v0.0.0")
    endif()

    # --- 5. git describe (полное: v1.2.3-15-gabc1234) ---
    execute_process(
        COMMAND ${GIT_EXECUTABLE} describe --tags --always --dirty
        WORKING_DIRECTORY "${SRC_DIR}"
        OUTPUT_VARIABLE GIT_DESCRIBE
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )

    # --- 6. Commits since tag ---
    execute_process(
        COMMAND ${GIT_EXECUTABLE} rev-list ${GIT_TAG}..HEAD --count
        WORKING_DIRECTORY "${SRC_DIR}"
        OUTPUT_VARIABLE GIT_COMMITS
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
        RESULT_VARIABLE COMMITS_RESULT
    )
    if(NOT COMMITS_RESULT EQUAL 0)
        set(GIT_COMMITS "0")
    endif()

    # --- 7. Commit date ---
    execute_process(
        COMMAND ${GIT_EXECUTABLE} log -1 --format=%ci
        WORKING_DIRECTORY "${SRC_DIR}"
        OUTPUT_VARIABLE GIT_DATE
        OUTPUT_STRIP_TRAILING_WHITESPACE
    )

    # --- 8. Parse SemVer from tag ---
    string(REGEX REPLACE "^v" "" CLEAN_TAG "${GIT_TAG}")
    if(CLEAN_TAG MATCHES "^([0-9]+)\\.([0-9]+)\\.([0-9]+)")
        set(VERSION_MAJOR "${CMAKE_MATCH_1}")
        set(VERSION_MINOR "${CMAKE_MATCH_2}")
        set(VERSION_PATCH "${CMAKE_MATCH_3}")
    else()
        set(VERSION_MAJOR 0)
        set(VERSION_MINOR 0)
        set(VERSION_PATCH 0)
    endif()

    message(STATUS "[version] ${GIT_DESCRIBE} (${GIT_BRANCH}) ${GIT_DATE}")
endif()

# --- 9. Build timestamp ---
string(TIMESTAMP BUILD_TIMESTAMP "%Y-%m-%d %H:%M:%S" UTC)

# --- 10. Составная строка версии ---
set(VERSION_STRING "${VERSION_MAJOR}.${VERSION_MINOR}.${VERSION_PATCH}")
if(GIT_COMMITS GREATER 0)
    string(APPEND VERSION_STRING ".${GIT_COMMITS}")
endif()
set(VERSION_FULL "${VERSION_STRING}-${GIT_HASH_SHORT}${GIT_DIRTY}")

# --- 11. Генерация version.h (только если содержимое изменилось!) ---
configure_file(
    "${SRC_DIR}/cmake/version.h.in"
    "${BIN_DIR}/generated/version.h"
    @ONLY
)
